from django.contrib import admin
from .models import InventoryItem

admin.site.register(InventoryItem)
